# ROJAS TRABAJA — Cómo ponerla en marcha

Todo gratis. Se puede hacer desde la computadora (recomendado para la primera vez) y después manejar desde el celular.

## Qué hay en esta carpeta
- `index.html` → la web.
- `data/ofertas.json` → las ofertas reales (las escribe el robot, no tocar).
- `data/ejemplos-zona.json` → ofertas de EJEMPLO de la zona. **Borralo cuando empiecen a llegar ofertas reales.**
- `robot/actualizar.py` → el robot que busca ofertas.
- `.github/workflows/actualizar.yml` → la orden de que el robot corra todos los días a las 6:00.

## Paso 1 · Subir el proyecto a GitHub
1. Creá una cuenta gratis en https://github.com
2. Tocá **New repository**, ponele de nombre `rojas-trabaja`, marcá **Public** y creálo.
3. Tocá **uploading an existing file** y arrastrá TODOS los archivos y carpetas de este ZIP (descomprimido).
   Importante: la carpeta `.github` empieza con punto y a veces queda oculta. Si no se sube, creá el archivo a mano:
   **Add file → Create new file**, nombre `.github/workflows/actualizar.yml`, y pegá el contenido.
4. Tocá **Commit changes**.

## Paso 2 · Publicar la web
1. En el proyecto, andá a **Settings → Pages**.
2. En "Branch" elegí `main` y la carpeta `/ (root)`. Guardá.
3. En 1–2 minutos la web queda en `https://TU-USUARIO.github.io/rojas-trabaja`. Ese link se abre sin cuenta y se puede mandar por WhatsApp.

## Paso 3 · Permitir que el robot guarde cambios
**Settings → Actions → General → Workflow permissions → Read and write permissions → Save.**

## Paso 4 · Formulario para empresas (Google Forms)
1. Creá un formulario en https://forms.google.com con estas preguntas (respetá los nombres):
   `Puesto`, `Empresa`, `Localidad`, `Rubro`, `Descripción`, `Contacto`, `Primer empleo` (opciones Sí/No).
2. En **Respuestas → Vincular con Hojas de cálculo**, creá la planilla.
3. En la planilla agregá una columna al final llamada `Aprobado`. Para publicar un aviso, escribí **Sí** en esa columna.
4. En la planilla: **Archivo → Compartir → Publicar en la web → (hoja de respuestas) → CSV → Publicar**. Copiá el link.
5. En GitHub: **Settings → Secrets and variables → Actions → New repository secret**.
   Nombre: `FORM_CSV_URL`, valor: el link que copiaste.
6. En `index.html`, el botón de "Publicar oferta" puede llevar directo al formulario de Google (pedile ayuda a quien te armó la web).

## Paso 5 (opcional) · Más ofertas de la zona con Jooble
1. Pedí la clave gratis en https://ar.jooble.org/api/about
2. Guardala como secret con el nombre `JOOBLE_KEY`.
   La clave gratuita tiene 500 consultas en total; el robot usa 1 por día.

## Paso 6 · Probar el robot
**Actions → Actualizar ofertas → Run workflow.** En 1 minuto tiene que aparecer un tilde verde y la web se actualiza.
Después corre solo todos los días a las 6:00 (hora de Argentina).

## Mantenimiento (5 minutos por semana)
- Revisar la planilla y poner **Sí** en los avisos nuevos que estén bien.
- Una vez por mes, entrar a **Actions** y ver que haya tildes verdes.
- Para sumar localidades: editar la lista `ZONA` en `robot/actualizar.py` y en `index.html`.
