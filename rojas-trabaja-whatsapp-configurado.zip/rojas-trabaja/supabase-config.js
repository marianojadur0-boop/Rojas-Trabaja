/* CONFIGURACIÓN PÚBLICA: completar con Project URL y anon/publishable key de Supabase.
   Nunca pegues aquí una service_role key ni una clave secreta. */
window.ROJAS_SUPABASE = {
  url: "PEGAR_URL_DEL_PROYECTO_SUPABASE",
  adminWhatsApp: '5492474566981', // Número internacional sin + ni espacios, ejemplo 549XXXXXXXXXX
  anonKey: "PEGAR_CLAVE_PUBLICA_ANON_O_PUBLISHABLE"
};
