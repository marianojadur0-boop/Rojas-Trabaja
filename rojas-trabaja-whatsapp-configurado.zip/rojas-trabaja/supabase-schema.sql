-- ROJAS TRABAJA: ejecutar en Supabase > SQL Editor.
-- Seguridad: nunca desactivar RLS ni publicar tablas privadas sin políticas.
create type public.user_role as enum ('candidate','company','admin');
create type public.account_status as enum ('pending','approved','blocked');
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.user_role not null default 'candidate',
  status public.account_status not null default 'pending',
  company_name text,
  created_at timestamptz not null default now()
);
create table public.candidate_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  first_name text not null,
  phone text,
  email text,
  locality text,
  age int check (age is null or age between 14 and 100),
  profession text,
  profile text,
  experience text,
  education text,
  skills text,
  first_job boolean not null default false,
  consent boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint consent_required check (consent = true)
);
create table public.vacancies (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  rubro text,
  locality text,
  description text,
  status text not null default 'pending' check(status in ('pending','open','closed','rejected')),
  created_at timestamptz not null default now()
);
create or replace function public.my_role() returns text language sql stable security definer set search_path=public as $$
  select role::text from public.profiles where id=auth.uid()
$$;
create or replace function public.my_status() returns text language sql stable security definer set search_path=public as $$
  select status::text from public.profiles where id=auth.uid()
$$;
alter table public.profiles enable row level security;
alter table public.candidate_profiles enable row level security;
alter table public.vacancies enable row level security;
-- Cada usuario puede leer su propio perfil; administración puede revisar perfiles y solicitudes.
create policy "profile self read" on public.profiles for select to authenticated using (id=auth.uid() or public.my_role()='admin');
create policy "profile self create" on public.profiles for insert to authenticated with check (id=auth.uid() and role='candidate' and status='pending');
create policy "profile self update safe" on public.profiles for update to authenticated using (id=auth.uid() and role='candidate') with check (id=auth.uid() and role='candidate');
create policy "admin manage profiles" on public.profiles for all to authenticated using (public.my_role()='admin') with check (public.my_role()='admin');
-- El postulante administra su registro; empresas aprobadas y admin pueden ver solo perfiles con consentimiento.
create policy "candidate self manage" on public.candidate_profiles for all to authenticated using (user_id=auth.uid() or public.my_role()='admin') with check ((user_id=auth.uid() and consent=true) or public.my_role()='admin');
create policy "approved company read consented candidates" on public.candidate_profiles for select to authenticated using (consent=true and public.my_role()='company' and public.my_status()='approved');
create policy "admin read candidates" on public.candidate_profiles for select to authenticated using (public.my_role()='admin');
create policy "company manage own vacancies" on public.vacancies for all to authenticated using (company_id=auth.uid() and public.my_role()='company' and public.my_status()='approved' or public.my_role()='admin') with check (company_id=auth.uid() and public.my_role()='company' and public.my_status()='approved' or public.my_role()='admin');
create policy "authenticated view open vacancies" on public.vacancies for select to authenticated using (status='open' or public.my_role()='admin' or company_id=auth.uid());
-- Crear el primer perfil de usuario después de iniciar sesión. El alta inicial queda pendiente.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,role,status) values(new.id,'candidate','pending') on conflict(id) do nothing; return new; end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
-- IMPORTANTE: luego de registrarte, promover TU usuario como admin con una consulta ejecutada por el dueño del proyecto:
-- update public.profiles set role='admin', status='approved' where id=(select id from auth.users where email='TU_CORREO_ADMIN');
-- Para habilitar una empresa, actualizar su fila: role='company', status='approved'. Verificar identidad comercial antes de hacerlo.
