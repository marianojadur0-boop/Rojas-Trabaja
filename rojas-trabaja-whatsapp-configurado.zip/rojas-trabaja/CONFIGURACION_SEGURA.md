# Acceso empresarial por clave individual — actualización

- Cada empresa solicita acceso por WhatsApp. Configurar `adminWhatsApp` en `supabase-config.js` (549... sin +).
- Registrar nombre, cargo, empresa, email, fecha, verificación, aprobación/rechazo y revocación. No poner la clave en una hoja pública ni en el código web.
- Crear la cuenta empresarial desde Supabase Authentication (no habilitar autorregistro empresarial); asignar contraseña única y robusta de al menos 12 caracteres por empresa, comunicarla por canal privado y exigir cambio si se sospecha exposición.
- En `profiles`, asignar a ese usuario `role='company'`, `status='approved'`, `company_name='...'` solo después de verificar la solicitud. Para revocar, cambiar `status='blocked'` y revocar sesiones desde backend/Auth. No compartir una contraseña general.
- El ingreso de empresas utiliza email + contraseña de Supabase; la verificación de postulantes continúa por enlace al correo. Admin usa su cuenta separada.
- Configurar Supabase según los pasos siguientes. Las credenciales y el rol deben comprobarse en el servidor con RLS; nunca confiar en ocultar HTML.
- Los perfiles de texto voluntariamente compartidos se consultan desde el panel. **La subida y descarga de archivos PDF adjuntos todavía no está implementada**: requiere bucket privado, políticas de Storage y URLs temporales emitidas tras autorización. No publicar CV en carpetas públicas.
- Antes de uso real: aviso de privacidad, consentimiento expreso, mecanismo de retiro/eliminación, pruebas con cuentas de empresa aprobada/bloqueada y revisión de seguridad.

# Paneles privados de Rojas Trabaja

## Qué se agregó
- Acceso por enlace de un solo uso al correo (magic link): no hay contraseña ni PIN.
- Las cuentas nuevas quedan pendientes. Una empresa solo puede ver perfiles después de que la administración la verifique y habilite.
- Panel de empresas para buscar perfiles que dieron consentimiento.
- Panel de administración con indicadores de perfiles, empresas, búsquedas laborales, edad promedio, profesiones/áreas, grupos etarios, rubros demandados y localidades.
- El perfil laboral se guarda únicamente si la persona marca consentimiento y confirma su identidad por correo.
- Las reglas de base de datos (RLS) restringen el acceso; ocultar paneles en pantalla no es la medida de seguridad.

## Importante antes de publicar
El ZIP anterior era una web estática de demostración. Para guardar y proteger datos reales hace falta conectar una base autenticada. No cargues datos personales reales hasta completar todos estos pasos y probar los permisos con cuentas separadas.

## Configuración gratuita con Supabase
1. Crear un proyecto en https://supabase.com/ y guardar la contraseña del proyecto en un lugar seguro.
2. Abrir **SQL Editor** y ejecutar todo el archivo `supabase-schema.sql`.
3. En **Authentication → URL Configuration**, poner la URL pública de la web en Site URL y agregarla a Redirect URLs. Para GitHub Pages suele ser `https://TU-USUARIO.github.io/rojas-trabaja/`.
4. En **Project Settings → API** copiar Project URL y la clave pública `anon`/`publishable`.
5. Pegar esos dos valores en `supabase-config.js`. No usar nunca `service_role` ni una clave secreta en la web.
6. Subir todos los archivos a GitHub Pages. Probar el ingreso por correo.
7. Una vez que tu usuario haya iniciado sesión por primera vez, ejecutar en SQL Editor la consulta de promoción al rol admin del final de `supabase-schema.sql`, reemplazando `TU_CORREO_ADMIN` por tu correo real.
8. Para habilitar una empresa, verificarla primero y cambiar su fila en `profiles` a `role='company', status='approved'`. No aprobar correos sin verificar.
9. Probar con tres cuentas diferentes: postulante, empresa aprobada y usuario administrador. Confirmar que una empresa no puede ver datos sin consentimiento ni administrar otras cuentas.

## Limitaciones actuales de esta versión
- Las empresas se habilitan manualmente desde Supabase; no hay todavía una pantalla de aprobación de empresas dentro del panel.
- El panel muestra perfiles voluntarios y estadísticas de los datos guardados en la nueva base. Las ofertas externas del robot siguen viniendo de `data/ofertas.json`; para que todas las ofertas cargadas por empresas alimenten las estadísticas, falta conectar el formulario de publicación con la tabla `vacancies`.
- La cuenta administradora debe mantenerse segura con el acceso al correo y autenticación multifactor en la cuenta proveedora cuando esté disponible.
- Definí un aviso de privacidad y un procedimiento para corregir/eliminar perfiles antes de abrirlo al público. Recopilá solo los datos necesarios y no solicites DNI, domicilio exacto ni datos sensibles.
- Esta configuración es una base técnica, no una certificación legal o auditoría de seguridad. Antes de cargar datos reales, revisar las políticas de acceso y las obligaciones aplicables de protección de datos personales en Argentina.
